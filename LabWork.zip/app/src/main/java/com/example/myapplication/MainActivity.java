        package com.example.myapplication;

        import android.content.DialogInterface;
        import android.content.Intent;
        import android.os.Bundle;
        import android.text.TextUtils;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.widget.Button;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AlertDialog;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.constraintlayout.widget.ConstraintLayout;

        import com.example.myapplication.Models.User;
        import com.google.android.gms.tasks.OnFailureListener;
        import com.google.android.gms.tasks.OnSuccessListener;


        import com.google.android.material.snackbar.Snackbar;
        import com.google.firebase.auth.AuthResult;
        import com.google.firebase.auth.FirebaseAuth;
        import com.google.firebase.database.DatabaseReference;
        import com.google.firebase.database.FirebaseDatabase;
        import com.rengwuxian.materialedittext.MaterialEditText;

public class MainActivity extends AppCompatActivity {
    Button reg_btn,log_btn;
    FirebaseAuth auth;
    FirebaseDatabase database;
    DatabaseReference users;

    ConstraintLayout root;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        log_btn=findViewById(R.id.log_btn);
        reg_btn=findViewById(R.id.reg_btn);
        root=findViewById(R.id.root_el);

        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        users = database.getReference("Users");



        reg_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRegistrationWindow();

            }
        });
        log_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLogWindow();

            }
        });
    }
    private  void showLogWindow(){
        AlertDialog.Builder dialog=new AlertDialog.Builder(this);
        dialog.setTitle("Войти");

        LayoutInflater inflater=LayoutInflater.from(this);
        View log_window = inflater.inflate(R.layout.log_window,null);
        dialog.setView(log_window);

        final MaterialEditText email= log_window.findViewById(R.id.emailField);
        final MaterialEditText pass= log_window.findViewById(R.id.PassField);

        //ОТМЕНА РЕГИСТРАЦИИ
        dialog.setNegativeButton("Отменить", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                dialogInterface.dismiss();
            }
        });
        //<ОТМЕНА РЕГИСТРАЦИИ
        //РЕГИСТРАЦИЯ
        dialog.setPositiveButton("Войти", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                if(TextUtils.isEmpty(email.getText().toString()))
                {
                    Snackbar.make(root,"Введите свою почту",Snackbar.LENGTH_LONG).show();

                    return;
                }
                if(TextUtils.isEmpty(pass.getText().toString()))
                {
                    Snackbar.make(root,"Введите пороль",Snackbar.LENGTH_LONG).show();
                    return;
                }
                auth.signInWithEmailAndPassword(email.getText().toString(),pass.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                startActivity(new Intent(MainActivity.this,Log.class));
                                finish();

                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Snackbar.make(root,"Ошибка авторизации."+ e.getMessage(),Snackbar.LENGTH_SHORT).show();

                    }
                });
            }
        });


        dialog.show();

    }

    private void showRegistrationWindow() {
        AlertDialog.Builder dialog=new AlertDialog.Builder(this);
        dialog.setTitle("Зарегистрироваться");

        LayoutInflater inflater=LayoutInflater.from(this);
        View registration = inflater.inflate(R.layout.registration,null);
        dialog.setView(registration);

        final MaterialEditText email= registration.findViewById(R.id.emailField);
        final MaterialEditText username= registration.findViewById(R.id.UsernameField);
        final MaterialEditText pass= registration.findViewById(R.id.PassField);

        //ОТМЕНА РЕГИСТРАЦИИ
        dialog.setNegativeButton("Отменить", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                dialogInterface.dismiss();
            }
        });
        //<ОТМЕНА РЕГИСТРАЦИИ
        //РЕГИСТРАЦИЯ
        dialog.setPositiveButton("Зарегистрироваться", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                if(TextUtils.isEmpty(email.getText().toString()))
                {
                    Snackbar.make(root,"Введите свой Email",Snackbar.LENGTH_LONG).show();
                    return;
                }
                if(TextUtils.isEmpty(pass.getText().toString()))
                {
                    Snackbar.make(root,"Введите пороль",Snackbar.LENGTH_LONG).show();
                    return;
                }
                auth.createUserWithEmailAndPassword(email.getText().toString(),pass.getText().toString())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                User user = new User();
                                user.setEmail(email.getText().toString());
                                user.setUsername(username.getText().toString());
                                user.setPass(pass.getText().toString());

                                users.child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                        .setValue(user)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Snackbar.make(root,"Пользователь добавлен", Snackbar.LENGTH_SHORT).show();


                                            }
                                        });
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Snackbar.make(root,"Пользователь с таким Email уже зарегистрирован."+ e.getMessage(),Snackbar.LENGTH_SHORT).show();
                    }
                });

            }
        });
        //<РЕГИСТРАЦИЯ
        dialog.show();


    }
}
